<?php
// This file declares a new entity type. For more details, see "hook_civicrm_entityTypes" at:
// http://wiki.civicrm.org/confluence/display/CRMDOC/Hook+Reference
return array (
  0 => 
  array (
    'name' => 'SebRenewal',
    'class' => 'CRM_Sebext_DAO_SebRenewal',
    'table' => 'civicrm_sebrenewal',
  ),
);
